"""
tests/test_api.py
==================
Smoke tests for the Flask API, using Flask's built-in test client (no
running server or Docker container required). Run with:

    pytest tests/ -v
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from app.main import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


VALID_CUSTOMER = {
    "age": 35, "gender": "Female", "tenure_months": 10, "contract_type": "One year",
    "payment_method": "Credit card", "signup_channel": "Web", "monthly_charges": 70.0,
    "num_support_tickets": 1, "satisfaction_score": 3,
}


def test_health_returns_200_when_model_loaded(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["status"] == "ok"
    assert body["model_loaded"] is True


def test_model_info_returns_metadata(client):
    resp = client.get("/model-info")
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["model_type"] == "RandomForestClassifier"
    assert "test_metrics" in body
    assert "roc_auc" in body["test_metrics"]


def test_predict_valid_customer_returns_200(client):
    resp = client.post("/predict", json=VALID_CUSTOMER)
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["churn_prediction"] in (0, 1)
    assert 0.0 <= body["churn_probability"] <= 1.0
    assert body["risk_tier"] in ("Low", "Medium", "High")
    assert "request_id" in body


def test_predict_missing_fields_returns_422(client):
    resp = client.post("/predict", json={"age": 30})
    assert resp.status_code == 422
    body = resp.get_json()
    assert body["error"] == "validation_error"
    assert len(body["details"]) > 0


def test_predict_invalid_category_returns_422(client):
    bad_customer = dict(VALID_CUSTOMER, contract_type="Lifetime")
    resp = client.post("/predict", json=bad_customer)
    assert resp.status_code == 422


def test_predict_non_json_body_returns_400(client):
    resp = client.post("/predict", data="not json", content_type="text/plain")
    assert resp.status_code == 400


def test_predict_satisfaction_score_out_of_range_returns_422(client):
    bad_customer = dict(VALID_CUSTOMER, satisfaction_score=99)
    resp = client.post("/predict", json=bad_customer)
    assert resp.status_code == 422


def test_batch_predict_returns_results_for_each_customer(client):
    resp = client.post("/predict/batch", json=[VALID_CUSTOMER, VALID_CUSTOMER])
    assert resp.status_code == 200
    body = resp.get_json()
    assert body["count"] == 2
    assert len(body["results"]) == 2


def test_batch_predict_rejects_non_list_body(client):
    resp = client.post("/predict/batch", json=VALID_CUSTOMER)
    assert resp.status_code == 400


def test_batch_predict_rejects_empty_list(client):
    resp = client.post("/predict/batch", json=[])
    assert resp.status_code == 400


def test_metrics_endpoint_reflects_requests(client):
    before = client.get("/metrics").get_json()["total_requests"]
    client.post("/predict", json=VALID_CUSTOMER)
    after = client.get("/metrics").get_json()["total_requests"]
    assert after > before


def test_higher_risk_profile_scores_higher_than_lower_risk_profile(client):
    """A directional sanity check on the model itself, not just the API
    plumbing: a month-to-month, low-tenure, low-satisfaction customer
    should score a higher churn probability than a two-year, long-tenure,
    high-satisfaction customer."""
    high_risk = {
        "age": 29, "gender": "Female", "tenure_months": 1, "contract_type": "Month-to-month",
        "payment_method": "Electronic check", "signup_channel": "Web", "monthly_charges": 90.0,
        "num_support_tickets": 5, "satisfaction_score": 1,
    }
    low_risk = {
        "age": 55, "gender": "Male", "tenure_months": 60, "contract_type": "Two year",
        "payment_method": "Credit card", "signup_channel": "Referral", "monthly_charges": 55.0,
        "num_support_tickets": 0, "satisfaction_score": 5,
    }
    resp_high = client.post("/predict", json=high_risk).get_json()
    resp_low = client.post("/predict", json=low_risk).get_json()
    assert resp_high["churn_probability"] > resp_low["churn_probability"]
