"""
train_model.py
===============
Reproduces the leak-free preprocessing pipeline and tuned Random Forest
model from the Week 2-3 deliverables, then saves every artifact the serving
API needs at inference time: the fitted model, the fitted preprocessing
transformers (encoder, scaler, ordinal encoder), the preprocessing
statistics learned on the training split (imputation median/mode, IQR
outlier fences), the final feature column order, and a metadata file
recording training-time metrics and hyperparameters.

Run this once (locally or as a Docker build step) before starting the API:
    python train_model.py

Outputs (all written to ./model_artifacts/):
    model.pkl                  - trained RandomForestClassifier
    encoder.pkl                - fitted OneHotEncoder (nominal categoricals)
    tenure_order.pkl           - fitted OrdinalEncoder (tenure_bucket)
    scaler.pkl                 - fitted StandardScaler
    preprocessing_stats.json   - imputation values + outlier fences (train-fit)
    feature_cols.json          - final ordered list of model input columns
    metadata.json              - hyperparameters, metrics, training timestamp
"""
import json
import pickle
import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder, OrdinalEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
)

RANDOM_STATE = 42
ARTIFACTS_DIR = Path(__file__).parent / "model_artifacts"
ARTIFACTS_DIR.mkdir(exist_ok=True)


def simulate_dataset(n=2000, random_state=RANDOM_STATE):
    """Simulate the same messy customer-churn dataset used in Weeks 2-4."""
    rng = np.random.default_rng(random_state)

    tenure_months = rng.gamma(shape=2.0, scale=12, size=n).clip(0, 72).round(0)
    contract_type = rng.choice(["Month-to-month", "One year", "Two year"], size=n, p=[0.55, 0.25, 0.20])
    base_charge = rng.normal(65, 20, size=n).clip(15, None)
    monthly_charges = base_charge + rng.normal(0, 5, size=n)

    age = rng.normal(42, 14, size=n).round(0)
    satisfaction_score = rng.integers(1, 6, size=n).astype(float)
    num_support_tickets = rng.poisson(1.2, size=n).astype(float)

    gender = rng.choice(["Female", "Male", "Other"], size=n, p=[0.48, 0.48, 0.04])
    signup_channel = rng.choice(["Web", "Referral", "Store", "Phone"], size=n, p=[0.4, 0.2, 0.25, 0.15])
    payment_method = rng.choice(["Credit card", "Bank transfer", "Electronic check", "Mailed check"], size=n)

    total_spend = tenure_months * monthly_charges * rng.normal(1.0, 0.08, size=n)

    df = pd.DataFrame({
        "customer_id": [f"CUST-{i:05d}" for i in range(n)],
        "age": age, "gender": gender, "tenure_months": tenure_months,
        "contract_type": contract_type, "payment_method": payment_method,
        "signup_channel": signup_channel, "monthly_charges": monthly_charges.round(2),
        "total_spend": total_spend.round(2), "num_support_tickets": num_support_tickets,
        "satisfaction_score": satisfaction_score,
    })

    missing_age_idx = rng.choice(n, size=int(0.04 * n), replace=False)
    df.loc[missing_age_idx, "age"] = np.nan
    missing_sat_idx = rng.choice(n, size=int(0.06 * n), replace=False)
    df.loc[missing_sat_idx, "satisfaction_score"] = np.nan
    missing_pay_idx = rng.choice(n, size=int(0.03 * n), replace=False)
    df.loc[missing_pay_idx, "payment_method"] = "?"

    outlier_age_idx = rng.choice(n, size=6, replace=False)
    df.loc[outlier_age_idx, "age"] = rng.choice([-5, 0, 105, 110, 118, 130], size=6, replace=False)
    outlier_charge_idx = rng.choice(n, size=8, replace=False)
    df.loc[outlier_charge_idx, "monthly_charges"] = rng.uniform(400, 900, size=8).round(2)
    outlier_ticket_idx = rng.choice(n, size=5, replace=False)
    df.loc[outlier_ticket_idx, "num_support_tickets"] = rng.integers(25, 40, size=5)

    churn_logit = (
        -1.2
        + 0.9 * (df["contract_type"] == "Month-to-month").astype(int)
        - 0.03 * df["tenure_months"].fillna(df["tenure_months"].median())
        - 0.25 * (df["satisfaction_score"].fillna(3) - 3)
        + 0.15 * (df["num_support_tickets"].clip(upper=6))
        + rng.normal(0, 0.6, size=n)
    )
    churn_prob = 1 / (1 + np.exp(-churn_logit))
    df["churn"] = (rng.uniform(size=n) < churn_prob).astype(int)
    return df


def iqr_bounds(s, k=1.5):
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr = q3 - q1
    return max(q1 - k * iqr, 0), q3 + k * iqr


def main():
    print("Simulating dataset...")
    df = simulate_dataset()

    # --- Fix disguised missing values and impossible values, then split ----
    df_prepared = df.copy()
    df_prepared["payment_method"] = df_prepared["payment_method"].replace("?", np.nan)
    implausible_age = (df_prepared["age"] < 0) | (df_prepared["age"] > 100)
    df_prepared.loc[implausible_age, "age"] = np.nan

    train_df, test_df = train_test_split(
        df_prepared, test_size=0.2, random_state=RANDOM_STATE, stratify=df_prepared["churn"]
    )
    train_df, test_df = train_df.copy(), test_df.copy()

    # --- Impute (fit on train only) -----------------------------------------
    age_median = float(train_df["age"].median())
    sat_mode = float(train_df["satisfaction_score"].mode()[0])
    for d in (train_df, test_df):
        d["age"] = d["age"].fillna(age_median)
        d["satisfaction_score"] = d["satisfaction_score"].fillna(sat_mode)
        d["payment_method"] = d["payment_method"].fillna("Unknown")

    # --- Outlier winsorizing (IQR fences fit on train only) ------------------
    outlier_fences = {}
    for col in ["monthly_charges", "num_support_tickets"]:
        lower, upper = iqr_bounds(train_df[col])
        outlier_fences[col] = {"lower": float(lower), "upper": float(upper)}
        for d in (train_df, test_df):
            d[col] = d[col].clip(lower=lower, upper=upper)

    # --- One-hot encode nominal categoricals (fit on train only) -------------
    nominal_cols = ["gender", "contract_type", "payment_method", "signup_channel"]
    encoder = OneHotEncoder(drop="first", sparse_output=False, handle_unknown="ignore")
    encoder.fit(train_df[nominal_cols])
    encoded_cols = list(encoder.get_feature_names_out(nominal_cols))

    def one_hot_encode(d):
        arr = encoder.transform(d[nominal_cols])
        enc_df = pd.DataFrame(arr, columns=encoded_cols, index=d.index)
        return pd.concat([d.drop(columns=nominal_cols + ["customer_id"]), enc_df], axis=1)

    train_model_df, test_model_df = one_hot_encode(train_df), one_hot_encode(test_df)

    # --- Feature engineering ---------------------------------------------------
    tenure_bins, tenure_labels = [-1, 6, 24, np.inf], ["New", "Established", "Loyal"]
    tenure_order = OrdinalEncoder(categories=[tenure_labels])
    tenure_order.fit(pd.DataFrame({"tenure_bucket": tenure_labels}))
    one_year_col = [c for c in train_model_df.columns if c.endswith("_One year")][0]
    two_year_col = [c for c in train_model_df.columns if c.endswith("_Two year")][0]

    def engineer_features(d):
        d = d.copy()
        d["avg_monthly_spend"] = d["total_spend"] / (d["tenure_months"] + 1)
        d["tenure_bucket"] = pd.cut(d["tenure_months"], bins=tenure_bins, labels=tenure_labels)
        d["tenure_bucket_encoded"] = tenure_order.transform(d[["tenure_bucket"]])
        d["tickets_per_tenure_month"] = d["num_support_tickets"] / (d["tenure_months"] + 1)
        d["is_month_to_month"] = ((d[one_year_col] == 0) & (d[two_year_col] == 0)).astype(int)
        d["low_satisfaction_flag"] = (d["satisfaction_score"] <= 2).astype(int)
        d["log_total_spend"] = np.log1p(d["total_spend"])
        return d.drop(columns=["tenure_bucket"])

    train_feat, test_feat = engineer_features(train_model_df), engineer_features(test_model_df)

    # --- Scale numeric features (fit on train only) ---------------------------
    scale_cols = ["age", "tenure_months", "monthly_charges", "total_spend", "num_support_tickets",
                  "avg_monthly_spend", "tickets_per_tenure_month", "log_total_spend"]
    scaler = StandardScaler()
    scaler.fit(train_feat[scale_cols])
    train_scaled, test_scaled = train_feat.copy(), test_feat.copy()
    train_scaled[scale_cols] = scaler.transform(train_feat[scale_cols])
    test_scaled[scale_cols] = scaler.transform(test_feat[scale_cols])

    # --- Drop features flagged as redundant by the Week 2 VIF check -----------
    drop_for_model = ["total_spend", "avg_monthly_spend"]
    feature_cols = [c for c in train_scaled.columns if c not in drop_for_model + ["churn"]]

    X_train, y_train = train_scaled[feature_cols].values, train_scaled["churn"].values
    X_test, y_test = test_scaled[feature_cols].values, test_scaled["churn"].values

    # --- Train the Week 3 tuned Random Forest ----------------------------------
    print("Training model...")
    model = RandomForestClassifier(
        n_estimators=300, max_depth=5, min_samples_split=5, min_samples_leaf=3,
        max_features="sqrt", class_weight="balanced", random_state=RANDOM_STATE,
    )
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]
    metrics = {
        "accuracy": round(float(accuracy_score(y_test, pred)), 4),
        "precision": round(float(precision_score(y_test, pred)), 4),
        "recall": round(float(recall_score(y_test, pred)), 4),
        "f1": round(float(f1_score(y_test, pred)), 4),
        "roc_auc": round(float(roc_auc_score(y_test, proba)), 4),
    }
    baseline_churn_rate = round(float(y_train.mean()), 4)
    print("Test metrics:", metrics)
    print("Training-set churn rate (monitoring baseline):", baseline_churn_rate)

    # --- Save all artifacts ------------------------------------------------------
    with open(ARTIFACTS_DIR / "model.pkl", "wb") as f:
        pickle.dump(model, f)
    with open(ARTIFACTS_DIR / "encoder.pkl", "wb") as f:
        pickle.dump(encoder, f)
    with open(ARTIFACTS_DIR / "tenure_order.pkl", "wb") as f:
        pickle.dump(tenure_order, f)
    with open(ARTIFACTS_DIR / "scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)

    preprocessing_stats = {
        "age_median": age_median,
        "satisfaction_mode": sat_mode,
        "outlier_fences": outlier_fences,
        "nominal_cols": nominal_cols,
        "encoded_cols": encoded_cols,
        "one_year_col": one_year_col,
        "two_year_col": two_year_col,
        "tenure_bins": tenure_bins,
        "tenure_labels": tenure_labels,
        "scale_cols": scale_cols,
        "drop_for_model": drop_for_model,
        "baseline_churn_rate": baseline_churn_rate,
    }
    with open(ARTIFACTS_DIR / "preprocessing_stats.json", "w") as f:
        json.dump(preprocessing_stats, f, indent=2)

    with open(ARTIFACTS_DIR / "feature_cols.json", "w") as f:
        json.dump(feature_cols, f, indent=2)

    metadata = {
        "model_version": "1.0.0",
        "model_type": "RandomForestClassifier",
        "trained_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "random_state": RANDOM_STATE,
        "hyperparameters": {
            "n_estimators": 300, "max_depth": 5, "min_samples_split": 5,
            "min_samples_leaf": 3, "max_features": "sqrt", "class_weight": "balanced",
        },
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "n_features": len(feature_cols),
        "test_metrics": metrics,
        "baseline_churn_rate": baseline_churn_rate,
    }
    with open(ARTIFACTS_DIR / "metadata.json", "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"\nAll artifacts written to {ARTIFACTS_DIR}/")
    for p in sorted(ARTIFACTS_DIR.iterdir()):
        print(" -", p.name)


if __name__ == "__main__":
    main()
