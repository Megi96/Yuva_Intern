"""
app/monitoring.py
==================
Lightweight, dependency-free in-memory monitoring for the prediction API.

This is intentionally simple (a process-local, in-memory store) rather than
wired up to a full metrics backend (Prometheus, Datadog, etc.), since the
task is to demonstrate the *mechanism* of monitoring an AI service, not to
stand up production observability infrastructure. The documentation
explains how this would be swapped for a real metrics backend in a genuine
production deployment (see the "Monitoring in Production" section of the
PDF report).

Tracked per-process:
    - total request / error / validation-error counts
    - a rolling window of the most recent request latencies (for avg/p95)
    - a rolling window of the most recent prediction outcomes (for a
      simple "prediction drift" heuristic: has the live churn-prediction
      rate drifted far from the rate observed in the training data?)
"""
import time
import threading
from collections import deque

DRIFT_THRESHOLD = 0.15         # absolute difference in churn rate that triggers a drift flag
ROLLING_WINDOW = 200            # number of recent requests kept for rolling stats
MIN_REQUESTS_FOR_DRIFT_CHECK = 20  # don't flag drift on a tiny, noisy sample


class Monitor:
    def __init__(self, baseline_churn_rate: float, rolling_window: int = ROLLING_WINDOW):
        self.baseline_churn_rate = baseline_churn_rate
        self.rolling_window = rolling_window
        self.start_time = time.time()
        self._lock = threading.Lock()

        self.total_requests = 0
        self.total_errors = 0
        self.total_validation_errors = 0
        self._latencies = deque(maxlen=rolling_window)
        self._predictions = deque(maxlen=rolling_window)  # 0/1 outcomes, most recent last

    def record_request(self, latency_ms=None, predicted_class=None, error=False,
                        validation_error=False):
        with self._lock:
            self.total_requests += 1
            if error:
                self.total_errors += 1
            if validation_error:
                self.total_validation_errors += 1
            if predicted_class is not None:
                self._latencies.append(latency_ms)
                self._predictions.append(predicted_class)

    def snapshot(self) -> dict:
        with self._lock:
            n = len(self._latencies)
            uptime_s = round(time.time() - self.start_time, 1)
            avg_latency = round(sum(self._latencies) / n, 2) if n else None
            p95_latency = round(sorted(self._latencies)[int(0.95 * (n - 1))], 2) if n else None
            rolling_churn_rate = round(sum(self._predictions) / n, 4) if n else None
            error_rate = round(self.total_errors / self.total_requests, 4) if self.total_requests else 0.0

            drift_flag = False
            drift_detail = None
            if n >= MIN_REQUESTS_FOR_DRIFT_CHECK and rolling_churn_rate is not None:
                gap = abs(rolling_churn_rate - self.baseline_churn_rate)
                drift_flag = gap > DRIFT_THRESHOLD
                drift_detail = {
                    "baseline_churn_rate": self.baseline_churn_rate,
                    "rolling_churn_rate": rolling_churn_rate,
                    "absolute_gap": round(gap, 4),
                    "threshold": DRIFT_THRESHOLD,
                }

            return {
                "uptime_seconds": uptime_s,
                "total_requests": self.total_requests,
                "total_errors": self.total_errors,
                "total_validation_errors": self.total_validation_errors,
                "error_rate": error_rate,
                "rolling_window_size": n,
                "avg_latency_ms": avg_latency,
                "p95_latency_ms": p95_latency,
                "rolling_prediction_churn_rate": rolling_churn_rate,
                "drift_flag": drift_flag,
                "drift_detail": drift_detail,
            }
