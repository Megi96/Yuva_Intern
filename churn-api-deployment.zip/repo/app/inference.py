"""
app/inference.py
=================
Loads the trained model and preprocessing artifacts once at startup, and
exposes a single `predict(raw_customer: dict) -> dict` function that
replicates, step for step, the exact preprocessing pipeline used at
training time (Weeks 2-3): impute with the *training-fit* median/mode,
clip outliers to the *training-fit* IQR fences, one-hot encode with the
*training-fit* encoder, engineer the same six features, and scale with the
*training-fit* scaler -- before finally calling the model.

Keeping this logic in a plain Python module (no Flask/pydantic imports)
means it can be unit-tested directly, independent of the web framework,
and is the same reason train/serve skew bugs are avoided: there is exactly
one implementation of "how a raw customer becomes a feature vector",
shared by training and serving.
"""
import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

ARTIFACTS_DIR = Path(__file__).parent.parent / "model_artifacts"

REQUIRED_FIELDS = [
    "age", "gender", "tenure_months", "contract_type", "payment_method",
    "signup_channel", "monthly_charges", "num_support_tickets", "satisfaction_score",
]

ALLOWED_VALUES = {
    "gender": ["Female", "Male", "Other"],
    "contract_type": ["Month-to-month", "One year", "Two year"],
    "payment_method": ["Credit card", "Bank transfer", "Electronic check", "Mailed check", "Unknown"],
    "signup_channel": ["Web", "Referral", "Store", "Phone"],
}


class ModelNotLoadedError(RuntimeError):
    pass


class ArtifactBundle:
    """Loads and holds every artifact needed to go from a raw customer
    dict to a prediction. Load once at process startup; reused (read-only)
    across every request."""

    def __init__(self, artifacts_dir: Path = ARTIFACTS_DIR):
        self.artifacts_dir = Path(artifacts_dir)
        self.model = None
        self.encoder = None
        self.tenure_order = None
        self.scaler = None
        self.stats = None
        self.feature_cols = None
        self.metadata = None
        self.loaded = False

    def load(self):
        try:
            with open(self.artifacts_dir / "model.pkl", "rb") as f:
                self.model = pickle.load(f)
            with open(self.artifacts_dir / "encoder.pkl", "rb") as f:
                self.encoder = pickle.load(f)
            with open(self.artifacts_dir / "tenure_order.pkl", "rb") as f:
                self.tenure_order = pickle.load(f)
            with open(self.artifacts_dir / "scaler.pkl", "rb") as f:
                self.scaler = pickle.load(f)
            with open(self.artifacts_dir / "preprocessing_stats.json") as f:
                self.stats = json.load(f)
            with open(self.artifacts_dir / "feature_cols.json") as f:
                self.feature_cols = json.load(f)
            with open(self.artifacts_dir / "metadata.json") as f:
                self.metadata = json.load(f)
            self.loaded = True
        except FileNotFoundError as e:
            self.loaded = False
            raise ModelNotLoadedError(
                f"Model artifacts not found in {self.artifacts_dir}. "
                f"Run `python train_model.py` before starting the API. Original error: {e}"
            ) from e


def validate_input(raw: dict) -> list:
    """Return a list of human-readable validation error strings (empty if valid)."""
    errors = []
    for field in REQUIRED_FIELDS:
        if field not in raw or raw[field] is None:
            errors.append(f"Missing required field: '{field}'")

    for field, allowed in ALLOWED_VALUES.items():
        if field in raw and raw[field] is not None and raw[field] not in allowed:
            errors.append(f"Field '{field}' must be one of {allowed}, got {raw[field]!r}")

    numeric_fields = ["age", "tenure_months", "monthly_charges", "num_support_tickets", "satisfaction_score"]
    for field in numeric_fields:
        if field in raw and raw[field] is not None:
            try:
                float(raw[field])
            except (TypeError, ValueError):
                errors.append(f"Field '{field}' must be numeric, got {raw[field]!r}")

    if "satisfaction_score" in raw and raw.get("satisfaction_score") is not None:
        try:
            sat = float(raw["satisfaction_score"])
            if not (1 <= sat <= 5):
                errors.append("Field 'satisfaction_score' must be between 1 and 5")
        except (TypeError, ValueError):
            pass

    return errors


def _preprocess(raw: dict, bundle: ArtifactBundle) -> np.ndarray:
    """Replicate the exact training-time preprocessing for a single raw customer."""
    stats = bundle.stats
    d = pd.DataFrame([raw])

    # --- Disguised-missing / impossible-value correction (matches training) ---
    d["payment_method"] = d["payment_method"].replace("?", np.nan)
    age_val = d.loc[0, "age"]
    if age_val is not None and (age_val < 0 or age_val > 100):
        d.loc[0, "age"] = np.nan

    # --- Impute using TRAINING-FIT statistics -----------------------------------
    d["age"] = d["age"].fillna(stats["age_median"])
    d["satisfaction_score"] = d["satisfaction_score"].fillna(stats["satisfaction_mode"])
    d["payment_method"] = d["payment_method"].fillna("Unknown")

    # --- Outlier winsorizing using TRAINING-FIT IQR fences -----------------------
    for col, fence in stats["outlier_fences"].items():
        d[col] = d[col].clip(lower=fence["lower"], upper=fence["upper"])

    # --- One-hot encode using the TRAINING-FIT encoder ----------------------------
    nominal_cols = stats["nominal_cols"]
    arr = bundle.encoder.transform(d[nominal_cols])
    enc_df = pd.DataFrame(arr, columns=stats["encoded_cols"], index=d.index)
    d = pd.concat([d.drop(columns=nominal_cols), enc_df], axis=1)

    # --- Feature engineering (identical to training) -------------------------------
    tenure_bins = stats["tenure_bins"]
    tenure_labels = stats["tenure_labels"]
    d["avg_monthly_spend"] = (d["monthly_charges"] * d["tenure_months"]) / (d["tenure_months"] + 1)
    # total_spend isn't collected from the API directly (it's dropped from the
    # model anyway per the Week 2 VIF check); log_total_spend below uses the
    # same tenure*charges proxy the training pipeline's total_spend represented.
    total_spend_proxy = d["monthly_charges"] * d["tenure_months"]
    d["tenure_bucket"] = pd.cut(d["tenure_months"], bins=tenure_bins, labels=tenure_labels)
    d["tenure_bucket_encoded"] = bundle.tenure_order.transform(d[["tenure_bucket"]])
    d["tickets_per_tenure_month"] = d["num_support_tickets"] / (d["tenure_months"] + 1)
    d["is_month_to_month"] = (
        (d.get(stats["one_year_col"], 0) == 0) & (d.get(stats["two_year_col"], 0) == 0)
    ).astype(int)
    d["low_satisfaction_flag"] = (d["satisfaction_score"] <= 2).astype(int)
    d["log_total_spend"] = np.log1p(total_spend_proxy)
    d["total_spend"] = total_spend_proxy  # needed only so scale_cols lines up below; dropped after scaling

    # --- Scale using the TRAINING-FIT scaler ----------------------------------------
    scale_cols = stats["scale_cols"]
    d[scale_cols] = bundle.scaler.transform(d[scale_cols])

    # --- Select final feature columns in the exact training-time order -------------
    x = d[bundle.feature_cols].values.astype(float)
    return x


def risk_tier(probability: float) -> str:
    if probability < 0.33:
        return "Low"
    elif probability < 0.66:
        return "Medium"
    return "High"


def predict(raw: dict, bundle: ArtifactBundle) -> dict:
    """Full prediction pipeline for one raw customer dict. Raises
    ModelNotLoadedError if artifacts weren't loaded; caller is responsible
    for calling validate_input() first for user-facing validation errors."""
    if not bundle.loaded:
        raise ModelNotLoadedError("Model artifacts are not loaded.")

    x = _preprocess(raw, bundle)
    proba = float(bundle.model.predict_proba(x)[0, 1])
    pred_class = int(proba >= 0.5)

    return {
        "churn_prediction": pred_class,
        "churn_probability": round(proba, 4),
        "risk_tier": risk_tier(proba),
        "model_version": bundle.metadata["model_version"],
    }
