"""
app/main.py
===========
Flask API serving the churn-prediction model.

Endpoints:
    GET  /health        - liveness/readiness check
    GET  /model-info     - model metadata (version, hyperparameters, training metrics)
    POST /predict        - predict churn for one customer
    POST /predict/batch   - predict churn for a list of customers
    GET  /metrics         - monitoring snapshot (usage stats, latency, drift flag)

Run locally (without Docker):
    python -m app.main
    # or: flask --app app.main run --host 0.0.0.0 --port 8000

Run via Docker: see Dockerfile / README.md.
"""
import time
import uuid
import traceback

from flask import Flask, request, jsonify, g

from app.inference import ArtifactBundle, predict as run_prediction, validate_input, ModelNotLoadedError
from app.monitoring import Monitor
from app.logging_config import configure_logging

logger = configure_logging()

app = Flask(__name__)

# --- Load model artifacts and initialize monitoring once, at process startup ---
bundle = ArtifactBundle()
try:
    bundle.load()
    monitor = Monitor(baseline_churn_rate=bundle.stats["baseline_churn_rate"])
    logger.info("Model artifacts loaded successfully", extra={
        "model_version": bundle.metadata["model_version"],
        "trained_at_utc": bundle.metadata["trained_at_utc"],
    })
except ModelNotLoadedError as e:
    # The app still starts (so /health can report the problem clearly rather
    # than the container failing to boot with an opaque error), but every
    # /predict call will return 503 until artifacts are made available.
    monitor = Monitor(baseline_churn_rate=0.0)
    logger.error("Failed to load model artifacts at startup", extra={"error": str(e)})


@app.before_request
def _start_timer():
    g._start_time = time.time()
    g._request_id = str(uuid.uuid4())


@app.after_request
def _log_request(response):
    # Catch-all request log (separate from the more detailed prediction log
    # emitted inside /predict), so every single request -- even a 404 or a
    # request to /health -- leaves an audit trail.
    latency_ms = round((time.time() - g.get("_start_time", time.time())) * 1000, 2)
    logger.info("request_completed", extra={
        "request_id": g.get("_request_id"),
        "method": request.method,
        "path": request.path,
        "status_code": response.status_code,
        "latency_ms": latency_ms,
    })
    response.headers["X-Request-ID"] = g.get("_request_id", "")
    return response


@app.errorhandler(Exception)
def _handle_unexpected_error(err):
    # Global safety net: log the full stack trace server-side for debugging,
    # but never leak internal exception details to the client -- return a
    # generic message plus a request ID the client can quote when reporting
    # the issue, so it can be correlated back to the detailed server log.
    request_id = g.get("_request_id", "unknown")
    logger.error("unhandled_exception", exc_info=True, extra={
        "request_id": request_id,
        "path": request.path,
    })
    monitor.record_request(error=True)
    return jsonify({
        "error": "internal_server_error",
        "message": "An unexpected error occurred while processing the request.",
        "request_id": request_id,
    }), 500


@app.route("/health", methods=["GET"])
def health():
    """Liveness + readiness check. Returns 200 only if the model is loaded
    and ready to serve predictions; returns 503 otherwise, so an
    orchestrator (Docker healthcheck, Kubernetes readiness probe, a load
    balancer) can correctly stop routing traffic to an unready instance."""
    status = "ok" if bundle.loaded else "model_not_loaded"
    code = 200 if bundle.loaded else 503
    return jsonify({
        "status": status,
        "model_loaded": bundle.loaded,
        "model_version": bundle.metadata["model_version"] if bundle.loaded else None,
        "uptime_seconds": monitor.snapshot()["uptime_seconds"],
    }), code


@app.route("/model-info", methods=["GET"])
def model_info():
    if not bundle.loaded:
        return jsonify({"error": "model_not_loaded"}), 503
    return jsonify(bundle.metadata), 200


@app.route("/predict", methods=["POST"])
def predict_one():
    request_id = g.get("_request_id")

    if not bundle.loaded:
        monitor.record_request(error=True)
        return jsonify({"error": "model_not_loaded", "request_id": request_id}), 503

    payload = request.get_json(silent=True)
    if payload is None:
        monitor.record_request(validation_error=True)
        return jsonify({"error": "invalid_json", "message": "Request body must be valid JSON.",
                         "request_id": request_id}), 400

    errors = validate_input(payload)
    if errors:
        monitor.record_request(validation_error=True)
        logger.warning("validation_failed", extra={"request_id": request_id, "errors": errors})
        return jsonify({"error": "validation_error", "details": errors, "request_id": request_id}), 422

    t0 = time.time()
    result = run_prediction(payload, bundle)
    latency_ms = round((time.time() - t0) * 1000, 2)

    monitor.record_request(latency_ms=latency_ms, predicted_class=result["churn_prediction"])
    logger.info("prediction_made", extra={
        "request_id": request_id,
        "input_summary": {
            "tenure_months": payload.get("tenure_months"),
            "contract_type": payload.get("contract_type"),
            "satisfaction_score": payload.get("satisfaction_score"),
        },
        "churn_prediction": result["churn_prediction"],
        "churn_probability": result["churn_probability"],
        "risk_tier": result["risk_tier"],
        "latency_ms": latency_ms,
    })

    result["request_id"] = request_id
    return jsonify(result), 200


@app.route("/predict/batch", methods=["POST"])
def predict_batch():
    request_id = g.get("_request_id")

    if not bundle.loaded:
        monitor.record_request(error=True)
        return jsonify({"error": "model_not_loaded", "request_id": request_id}), 503

    payload = request.get_json(silent=True)
    if not isinstance(payload, list):
        monitor.record_request(validation_error=True)
        return jsonify({"error": "invalid_body", "message": "Batch endpoint expects a JSON array of customers.",
                         "request_id": request_id}), 400
    if len(payload) == 0:
        return jsonify({"error": "empty_batch", "request_id": request_id}), 400
    if len(payload) > 500:
        monitor.record_request(validation_error=True)
        return jsonify({"error": "batch_too_large", "message": "Maximum 500 customers per batch request.",
                         "request_id": request_id}), 400

    results = []
    for i, customer in enumerate(payload):
        errors = validate_input(customer)
        if errors:
            monitor.record_request(validation_error=True)
            results.append({"index": i, "error": "validation_error", "details": errors})
            continue
        t0 = time.time()
        result = run_prediction(customer, bundle)
        latency_ms = round((time.time() - t0) * 1000, 2)
        monitor.record_request(latency_ms=latency_ms, predicted_class=result["churn_prediction"])
        result["index"] = i
        results.append(result)

    logger.info("batch_prediction_made", extra={
        "request_id": request_id, "batch_size": len(payload),
        "n_errors": sum(1 for r in results if "error" in r),
    })
    return jsonify({"request_id": request_id, "count": len(results), "results": results}), 200


@app.route("/metrics", methods=["GET"])
def metrics():
    snap = monitor.snapshot()
    snap["model_loaded"] = bundle.loaded
    snap["model_version"] = bundle.metadata["model_version"] if bundle.loaded else None
    return jsonify(snap), 200


if __name__ == "__main__":
    # Flask's built-in dev server -- fine for local testing and for the
    # `simulate_requests.py` demo, but the Dockerfile uses gunicorn (a
    # production WSGI server) for the actual container image; see README.md.
    app.run(host="0.0.0.0", port=8000, debug=False)
