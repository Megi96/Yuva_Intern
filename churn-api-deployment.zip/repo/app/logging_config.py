"""
app/logging_config.py
======================
Configures structured (JSON-lines) logging for the prediction API, writing
to both stdout (so `docker logs` captures everything with zero extra
configuration) and a rotating log file under ./logs/, so logs survive
container restarts if the ./logs directory is mounted as a volume.

Each log record is a single JSON object per line, which makes the log
stream directly parseable by log aggregation tools (e.g. a Fluentd/Filebeat
sidecar shipping to Elasticsearch or CloudWatch) without any custom parsing
rules -- a standard practice for containerized services.
"""
import json
import logging
import logging.handlers
import sys
from pathlib import Path

LOG_DIR = Path(__file__).parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)


class JsonFormatter(logging.Formatter):
    def format(self, record):
        payload = {
            "timestamp": self.formatTime(record, datefmt="%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        # Allow callers to attach structured fields via `extra={...}`
        for key, value in record.__dict__.items():
            if key in ("args", "msg", "levelname", "levelno", "name", "pathname", "filename",
                       "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
                       "created", "msecs", "relativeCreated", "thread", "threadName",
                       "processName", "process", "message", "taskName"):
                continue
            payload[key] = value
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_logging(level=logging.INFO) -> logging.Logger:
    logger = logging.getLogger("churn_api")
    logger.setLevel(level)
    logger.handlers.clear()

    formatter = JsonFormatter()

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_DIR / "app.log", maxBytes=5 * 1024 * 1024, backupCount=3
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    logger.propagate = False
    return logger
