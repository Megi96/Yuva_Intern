"""
simulate_requests.py
=====================
Demonstrates the deployed API's functionality end-to-end using simulated,
dummy customer inputs -- no real customer data required. Sends a mix of
valid requests (spanning low, medium, and high churn-risk profiles),
intentionally invalid requests (to demonstrate validation/error handling),
and a batch request, then prints the resulting /metrics snapshot so you can
see monitoring data update in response to real traffic.

Usage (against a running container or local server):
    python simulate_requests.py --url http://localhost:8000
    python simulate_requests.py --url http://localhost:8000 --n 50   # heavier load

Requires: `pip install requests` (already in requirements.txt).
"""
import argparse
import json
import random
import time

import requests

DUMMY_PROFILES = [
    # (label, customer dict) -- a spread of realistic-looking synthetic customers
    ("high_risk_new_month_to_month", {
        "age": 27, "gender": "Female", "tenure_months": 1, "contract_type": "Month-to-month",
        "payment_method": "Electronic check", "signup_channel": "Web", "monthly_charges": 92.5,
        "num_support_tickets": 5, "satisfaction_score": 1,
    }),
    ("loyal_two_year_satisfied", {
        "age": 54, "gender": "Male", "tenure_months": 58, "contract_type": "Two year",
        "payment_method": "Credit card", "signup_channel": "Referral", "monthly_charges": 58.0,
        "num_support_tickets": 0, "satisfaction_score": 5,
    }),
    ("mid_tenure_one_year_neutral", {
        "age": 41, "gender": "Other", "tenure_months": 18, "contract_type": "One year",
        "payment_method": "Bank transfer", "signup_channel": "Store", "monthly_charges": 70.25,
        "num_support_tickets": 2, "satisfaction_score": 3,
    }),
    ("frustrated_established_customer", {
        "age": 36, "gender": "Female", "tenure_months": 14, "contract_type": "Month-to-month",
        "payment_method": "Mailed check", "signup_channel": "Phone", "monthly_charges": 81.0,
        "num_support_tickets": 6, "satisfaction_score": 2,
    }),
    ("new_but_happy_customer", {
        "age": 30, "gender": "Male", "tenure_months": 3, "contract_type": "One year",
        "payment_method": "Credit card", "signup_channel": "Web", "monthly_charges": 65.0,
        "num_support_tickets": 0, "satisfaction_score": 4,
    }),
]

INVALID_PROFILES = [
    ("missing_required_fields", {"age": 40, "gender": "Female"}),
    ("invalid_contract_type", {
        "age": 40, "gender": "Female", "tenure_months": 10, "contract_type": "Lifetime",
        "payment_method": "Credit card", "signup_channel": "Web", "monthly_charges": 60.0,
        "num_support_tickets": 1, "satisfaction_score": 3,
    }),
    ("satisfaction_score_out_of_range", {
        "age": 40, "gender": "Female", "tenure_months": 10, "contract_type": "One year",
        "payment_method": "Credit card", "signup_channel": "Web", "monthly_charges": 60.0,
        "num_support_tickets": 1, "satisfaction_score": 12,
    }),
]


def jitter_profile(profile: dict) -> dict:
    """Add small random jitter to a base profile so repeated simulated
    requests aren't byte-for-byte identical, more realistically exercising
    the model and the monitoring rolling window."""
    p = dict(profile)
    p["age"] = max(18, p["age"] + random.randint(-3, 3))
    p["tenure_months"] = max(0, p["tenure_months"] + random.randint(-1, 1))
    p["monthly_charges"] = round(max(15.0, p["monthly_charges"] + random.uniform(-5, 5)), 2)
    p["num_support_tickets"] = max(0, p["num_support_tickets"] + random.randint(-1, 1))
    return p


def main():
    parser = argparse.ArgumentParser(description="Send simulated traffic to the churn prediction API.")
    parser.add_argument("--url", default="http://localhost:8000", help="Base URL of the running API")
    parser.add_argument("--n", type=int, default=20, help="Number of valid requests to send")
    args = parser.parse_args()

    base = args.url.rstrip("/")

    print(f"--- Checking health at {base}/health ---")
    r = requests.get(f"{base}/health", timeout=5)
    print(r.status_code, r.json())
    if r.status_code != 200:
        print("API is not healthy; aborting simulation.")
        return

    print(f"\n--- Fetching model info from {base}/model-info ---")
    r = requests.get(f"{base}/model-info", timeout=5)
    print(json.dumps(r.json(), indent=2))

    print(f"\n--- Sending {args.n} valid, jittered dummy customer requests ---")
    for i in range(args.n):
        label, base_profile = random.choice(DUMMY_PROFILES)
        customer = jitter_profile(base_profile)
        t0 = time.time()
        r = requests.post(f"{base}/predict", json=customer, timeout=5)
        elapsed_ms = round((time.time() - t0) * 1000, 1)
        body = r.json()
        print(f"  [{i+1:02d}/{args.n}] profile={label:32s} -> "
              f"status={r.status_code} churn_pred={body.get('churn_prediction')} "
              f"proba={body.get('churn_probability')} tier={body.get('risk_tier')} "
              f"({elapsed_ms} ms)")

    print(f"\n--- Sending {len(INVALID_PROFILES)} intentionally invalid requests (expect 4xx) ---")
    for label, customer in INVALID_PROFILES:
        r = requests.post(f"{base}/predict", json=customer, timeout=5)
        print(f"  {label:32s} -> status={r.status_code}  body={r.json()}")

    print(f"\n--- Sending 1 batch request ({len(DUMMY_PROFILES)} customers) ---")
    r = requests.post(f"{base}/predict/batch", json=[p for _, p in DUMMY_PROFILES], timeout=10)
    print(f"  status={r.status_code}  count={r.json().get('count')}")

    print(f"\n--- Final /metrics snapshot ---")
    r = requests.get(f"{base}/metrics", timeout=5)
    print(json.dumps(r.json(), indent=2))


if __name__ == "__main__":
    main()
